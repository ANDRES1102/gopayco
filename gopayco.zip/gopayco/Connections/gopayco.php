<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_gopayco = "localhost";
$database_gopayco = "gopayco";
$username_gopayco = "root";
$password_gopayco = "";
$gopayco = mysql_pconnect($hostname_gopayco, $username_gopayco, $password_gopayco) or trigger_error(mysql_error(),E_USER_ERROR); 


date_default_timezone_set("America/Bogota");
?>