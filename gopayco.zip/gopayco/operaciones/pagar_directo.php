<?php require_once('../Connections/gopayco.php'); ?>
<?php
error_reporting(0);
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "activo";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php?accesscheck=lock";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_solicitud_pago = "-1";
if (isset($_POST['id'])) {
  $colname_solicitud_pago = $_POST['id'];
}
mysql_select_db($database_gopayco, $gopayco);
$query_solicitud_pago = sprintf("SELECT * FROM solicitud_pago WHERE id_solicitud_pago = %s", GetSQLValueString($colname_solicitud_pago, "int"));
$solicitud_pago = mysql_query($query_solicitud_pago, $gopayco) or die(mysql_error());
$row_solicitud_pago = mysql_fetch_assoc($solicitud_pago);
$totalRows_solicitud_pago = mysql_num_rows($solicitud_pago);

$colname_usuario_pagante = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_usuario_pagante = $_SESSION['MM_Username'];
}
mysql_select_db($database_gopayco, $gopayco);
$query_usuario_pagante = sprintf("SELECT * FROM `user` WHERE user_user = %s", GetSQLValueString($colname_usuario_pagante, "int"));
$usuario_pagante = mysql_query($query_usuario_pagante, $gopayco) or die(mysql_error());
$row_usuario_pagante = mysql_fetch_assoc($usuario_pagante);
$totalRows_usuario_pagante = mysql_num_rows($usuario_pagante);

$colname_saldo_pagante_user = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_saldo_pagante_user = $_SESSION['MM_Username'];
}
mysql_select_db($database_gopayco, $gopayco);
$query_saldo_pagante_user = sprintf("SELECT * FROM saldos WHERE user_saldos = %s", GetSQLValueString($colname_saldo_pagante_user, "int"));
$saldo_pagante_user = mysql_query($query_saldo_pagante_user, $gopayco) or die(mysql_error());
$row_saldo_pagante_user = mysql_fetch_assoc($saldo_pagante_user);
$totalRows_saldo_pagante_user = mysql_num_rows($saldo_pagante_user);
mysql_select_db($database_gopayco, $gopayco);
$query_saldo_gopayco = "SELECT * FROM saldo_gopayco";
$saldo_gopayco = mysql_query($query_saldo_gopayco, $gopayco) or die(mysql_error());
$row_saldo_gopayco = mysql_fetch_assoc($saldo_gopayco);
$totalRows_saldo_gopayco = mysql_num_rows($saldo_gopayco);

mysql_select_db($database_gopayco, $gopayco);
$query_comision_usuario = "SELECT * FROM comision_user WHERE minimo_valor_comision_user <= ".$row_solicitud_pago['valor_solicitud_pago']." AND maximo_valor_comision_user >= ".$row_solicitud_pago['valor_solicitud_pago']."";
$comision_usuario = mysql_query($query_comision_usuario, $gopayco) or die(mysql_error());
$row_comision_usuario = mysql_fetch_assoc($comision_usuario);
$totalRows_comision_usuario = mysql_num_rows($comision_usuario);

?>
<doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title>
<!-- 
Para obtener más información sobre los comentarios condicionales situados alrededor de las etiquetas html en la parte superior del archivo:
paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/
  
Haga lo siguiente si usa su compilación personalizada de modernizr (http://www.modernizr.com/):
* inserte el vínculo del código js aquí
* elimine el vínculo situado debajo para html5shiv
* añada la clase "no-js" a las etiquetas html en la parte superior
* también puede eliminar el vínculo con respond.min.js si ha incluido MQ Polyfill en su compilación de modernizr 
-->
<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</script>
<link href="../jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css">
<script src="../jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="../jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
<script src="../js/teclado_numerico.js" type="text/javascript"></script>
<style>
body{
	font-family:Verdana, Geneva, sans-serif;
	}
</style>
</head>
<body>
<img src="../image/loader.gif" width="128" height="128"><br>
Cargando<br>Por favor espere
<?php
// confirmacion de claves 
if($_POST['clave'] == $row_usuario_pagante['clave_user']){
	
	//conocer que tipo de usuario es
	if($row_solicitud_pago['tipo_usuario_solicitud_pago'] == 'cliente'){
		
		//si es un cliente
		//verificamos que tenga saldo suficiente
		if($row_saldo_pagante_user['valor_saldos'] >= $row_solicitud_pago['valor_solicitud_pago'] && $row_solicitud_pago['moneda_solicitud_pago'] == $row_saldo_pagante_user['moneda_saldos']){
			//se realiza el pago
			//se le resta el saldo al usuario
			$resta_saldo_user = $row_saldo_pagante_user['valor_saldos'] - $row_solicitud_pago['valor_solicitud_pago'];
			mysql_select_db($database_gopayco, $gopayco);
$query_saldo_usuario = "UPDATE saldos SET valor_saldos = '".$resta_saldo_user."' WHERE user_saldos = '".$row_usuario_pagante['user_user']."'";
$saldo_usuario = mysql_query($query_saldo_usuario, $gopayco) or die(mysql_error());


//se le suma saldo al cliente restando comision
	//se busca el saldo del cliente
mysql_select_db($database_gopayco, $gopayco);
$query_saldo_cliente = "SELECT * FROM saldo_cliente WHERE cliente_saldo_cliente = '".$row_solicitud_pago['solicitante_solicitud_pago']."'";
$saldo_cliente = mysql_query($query_saldo_cliente, $gopayco) or die(mysql_error());
$row_saldo_cliente = mysql_fetch_assoc($saldo_cliente);
$totalRows_saldo_cliente = mysql_num_rows($saldo_cliente);
	//se obtiene la comision del cliente
mysql_select_db($database_gopayco, $gopayco);
$query_comision_cliente = "SELECT * FROM plan_cliente WHERE cliente_plan_cliente = '".$row_solicitud_pago['solicitante_solicitud_pago']."'";
$comision_cliente = mysql_query($query_comision_cliente, $gopayco) or die(mysql_error());
$row_comision_cliente = mysql_fetch_assoc($comision_cliente);
$totalRows_comision_cliente = mysql_num_rows($comision_cliente);
	//se suma el valor al cliente
$suma_saldo_cliente = $row_saldo_cliente['valor_saldo_cliente'] +( $row_solicitud_pago['valor_solicitud_pago'] - ($row_solicitud_pago['valor_solicitud_pago'] * $row_comision_cliente['comision_plan_cliente']/ 100));
mysql_select_db($database_gopayco, $gopayco);
$query_saldo_clientex = "UPDATE saldo_cliente SET valor_saldo_cliente = '".$suma_saldo_cliente."' WHERE cliente_saldo_cliente = '".$row_solicitud_pago['solicitante_solicitud_pago']."'";
$saldo_clientex = mysql_query($query_saldo_clientex, $gopayco) or die(mysql_error());
	//se agrega el movimiento al usuario
mysql_select_db($database_gopayco, $gopayco);
$query_movimiento_user = "INSERT INTO movimientos_cuenta (user_movimientos_cuenta, cliente_movimientos_cuenta, concepto_movimientos_cuenta, debe_movimientos_cuenta, haber_movimientos_cuenta, moneda_movimientos_cuenta, fecha_movimientos_cuenta)VALUES('".$row_usuario_pagante['user_user']."', '".$row_solicitud_pago['solicitante_solicitud_pago']."', '".$row_solicitud_pago['concepto_solicitud_pago']."', '0','".$row_solicitud_pago['valor_solicitud_pago']."', '".$row_solicitud_pago['moneda_solicitud_pago']."', '".date('Y-m-d')."')";
$movimiento_user = mysql_query($query_movimiento_user, $gopayco) or die(mysql_error());
	//se agrega el movimiento al cliente
	$valor_recibido_cliente = $row_solicitud_pago['valor_solicitud_pago']-($row_solicitud_pago['valor_solicitud_pago'] * $row_comision_cliente['comision_plan_cliente']/ 100);
mysql_select_db($database_gopayco, $gopayco);
$query_movimiento_cliente = "INSERT INTO movimientos_cliente (cliente_movimientos_cliente, user_movimientos_cliente, valor_movimintos_cliente, debe_movimientos_cliente, haber_movimientos_cliente, moneda_movimientos_cliente, concepto_movimientos_cliente, fecha_movimientos_cliente, cajero_movimientos_cliente)VALUES('".$row_solicitud_pago['solicitante_solicitud_pago']."', '".$row_solicitud_pago['user_solicitud_pago']."', '".$row_solicitud_pago['valor_solicitud_pago']."', '".$valor_recibido_cliente."', '0', '".$row_solicitud_pago['moneda_solicitud_pago']."', '".$row_solicitud_pago['concepto_solicitud_pago']."', '".date('Y-m-d')."', '".$row_solicitud_pago['cajero_solicitud_pago']."')";
$movimiento_cliente = mysql_query($query_movimiento_cliente, $gopayco) or die(mysql_error());
//ganancias gopayco
$suma_ganancias_gopayco = $row_saldo_gopayco['valor_saldo_gopayco']+($row_solicitud_pago['valor_solicitud_pago'] * $row_comision_cliente['comision_plan_cliente']/ 100);
mysql_select_db($database_gopayco, $gopayco);
$query_ganancias_cliente= "UPDATE saldo_gopayco SET valor_saldo_gopayco= '".$suma_ganancias_gopayco."'";
$ganancias_cliente = mysql_query($query_ganancias_cliente, $gopayco) or die(mysql_error());
//solicitud modificar
mysql_select_db($database_gopayco, $gopayco);
$query_ganancias_cliente= "UPDATE solicitud_pago SET estado_solicitud_pago = 'false', informado_solicitud_pago = 'false' WHERE user_solicitud_pago = '".$row_solicitud_pago['user_solicitud_pago']."'";
$ganancias_cliente = mysql_query($query_ganancias_cliente, $gopayco) or die(mysql_error());
header("Location: pago_realizado.php");
			}else{
				//se redirige por falta de fondos
				header("Location: error_saldo.php");
				}

	}else{
		//si es un usuario
				//verificamos que tenga saldo suficiente
		if($row_saldo_pagante_user['valor_saldos'] >= $row_solicitud_pago['valor_solicitud_pago'] && $row_solicitud_pago['moneda_solicitud_pago'] == $row_saldo_pagante_user['moneda_saldos']){
			//se realiza el pago
			//se le resta el saldo al usuario
			$resta_saldo_user = $row_saldo_pagante_user['valor_saldos'] - $row_solicitud_pago['valor_solicitud_pago'];
			mysql_select_db($database_gopayco, $gopayco);
$query_saldo_usuario = "UPDATE saldos SET valor_saldos = '".$resta_saldo_user."' WHERE user_saldos = '".$row_usuario_pagante['user_user']."'";
$saldo_usuario = mysql_query($query_saldo_usuario, $gopayco) or die(mysql_error());


//se le suma saldo al otro usuario restando comision
	//se busca el saldo del cliente
mysql_select_db($database_gopayco, $gopayco);
$query_otro_usuario = "SELECT * FROM saldos WHERE user_saldos = '".$row_solicitud_pago['solicitante_solicitud_pago']."'";
$otro_usuario = mysql_query($query_otro_usuario, $gopayco) or die(mysql_error());
$row_otro_usuario = mysql_fetch_assoc($otro_usuario);
$totalRows_otro_usuario = mysql_num_rows($otro_usuario);

	//se suma el valor al cliente
$suma_saldo_cliente = $row_otro_usuario['valor_saldos'] +( $row_solicitud_pago['valor_solicitud_pago'] - ($row_solicitud_pago['valor_solicitud_pago'] * $row_comision_usuario['valor_comision_user']/ 100));
mysql_select_db($database_gopayco, $gopayco);
$query_saldo_otro_usuario = "UPDATE saldos SET valor_saldos = '".$suma_saldo_cliente."' WHERE user_saldos = '".$row_solicitud_pago['solicitante_solicitud_pago']."'";
$saldo_otro_usuario = mysql_query($query_saldo_otro_usuario, $gopayco) or die(mysql_error());
	//se agrega el movimiento al usuario
mysql_select_db($database_gopayco, $gopayco);
$query_movimiento_user = "INSERT INTO movimientos_cuenta (user_movimientos_cuenta, cliente_movimientos_cuenta, concepto_movimientos_cuenta, debe_movimientos_cuenta, haber_movimientos_cuenta, moneda_movimientos_cuenta, fecha_movimientos_cuenta)VALUES('".$row_usuario_pagante['user_user']."', '".$row_solicitud_pago['solicitante_solicitud_pago']."', '".$row_solicitud_pago['concepto_solicitud_pago']."', '0','".$row_solicitud_pago['valor_solicitud_pago']."', '".$row_solicitud_pago['moneda_solicitud_pago']."', '".date('Y-m-d')."')";
$movimiento_user = mysql_query($query_movimiento_user, $gopayco) or die(mysql_error());
	//se agrega el movimiento al otro usuario
	$valor_recibido_cliente = $row_solicitud_pago['valor_solicitud_pago']-($row_solicitud_pago['valor_solicitud_pago'] * $row_comision_usuario['valor_comision_user']/ 100);

mysql_select_db($database_gopayco, $gopayco);
$query_movimiento_user_otro = "INSERT INTO movimientos_cuenta (user_movimientos_cuenta, cliente_movimientos_cuenta, concepto_movimientos_cuenta, debe_movimientos_cuenta, haber_movimientos_cuenta, moneda_movimientos_cuenta, fecha_movimientos_cuenta)VALUES('".$row_solicitud_pago['solicitante_solicitud_pago']."', '".$row_usuario_pagante['user_user']."', '".$row_solicitud_pago['concepto_solicitud_pago']."', '".$valor_recibido_cliente."', '0', '".$row_solicitud_pago['moneda_solicitud_pago']."', '".date('Y-m-d')."')";
$movimiento_user_otro = mysql_query($query_movimiento_user_otro, $gopayco) or die(mysql_error());
//ganancias gopayco
$suma_ganancias_gopayco = $row_saldo_gopayco['valor_saldo_gopayco']+($row_solicitud_pago['valor_solicitud_pago'] * $row_comision_usuario['valor_comision_user']/ 100);
mysql_select_db($database_gopayco, $gopayco);
$query_ganancias_cliente= "UPDATE saldo_gopayco SET valor_saldo_gopayco= '".$suma_ganancias_gopayco."'";
$ganancias_cliente = mysql_query($query_ganancias_cliente, $gopayco) or die(mysql_error());
//solicitud modificar
mysql_select_db($database_gopayco, $gopayco);
$query_ganancias_cliente= "UPDATE solicitud_pago SET estado_solicitud_pago = 'false', informado_solicitud_pago = 'false' WHERE user_solicitud_pago = '".$row_solicitud_pago['user_solicitud_pago']."'";
$ganancias_cliente = mysql_query($query_ganancias_cliente, $gopayco) or die(mysql_error());
header("Location: pago_realizado.php");
			}else{
				//se redirige por falta de fondos
				header("Location: error_saldo.php");
				}
		}
	}else{
	
	//claves no coinciden - se resta un intento y se redirige a la pagina error_clave.php
	$resta = $row_usuario_pagante['intentos_clave_user'] - 1;
		mysql_select_db($database_gopayco, $gopayco);
$query_clave = "UPDATE user SET intentos_clave_user = '".$resta."' WHERE user_user = '".$row_usuario_pagante['user_user']."'";
$clave = mysql_query($query_clave, $gopayco) or die(mysql_error());
echo $resta;
		header("Location: error_clave.php");
	}
?>
</body>
</html>
<?php
mysql_free_result($solicitud_pago);

mysql_free_result($usuario_pagante);

mysql_free_result($saldo_pagante_user);

mysql_free_result($saldo_cliente);

mysql_free_result($comision_cliente);

mysql_free_result($comision_usuario);

mysql_free_result($saldo_gopayco);

mysql_free_result($otro_usuario);
?>
