<?php
error_reporting(0);
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
$colname_solicitud = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_solicitud = $_SESSION['MM_Username'];
}
mysql_select_db($database_gopayco, $gopayco);
$query_solicitud = sprintf("SELECT * FROM solicitud_pago WHERE user_solicitud_pago = %s AND estado_solicitud_pago = 'true' AND informado_solicitud_pago = 'true'", GetSQLValueString($colname_solicitud, "int"));
$solicitud = mysql_query($query_solicitud, $gopayco) or die(mysql_error());
$row_solicitud = mysql_fetch_assoc($solicitud);
$totalRows_solicitud = mysql_num_rows($solicitud);

mysql_select_db($database_gopayco, $gopayco);
$query_cliente = "SELECT * FROM cliente WHERE cliente_cliente = '".$row_solicitud['solicitante_solicitud_pago']."'";
$cliente = mysql_query($query_cliente, $gopayco) or die(mysql_error());
$row_cliente = mysql_fetch_assoc($cliente);
$totalRows_cliente = mysql_num_rows($cliente);

mysql_select_db($database_gopayco, $gopayco);
$query_user_solicitante = "SELECT * FROM `user` WHERE user_user = '".$row_solicitud['solicitante_solicitud_pago']."'";
$user_solicitante = mysql_query($query_user_solicitante, $gopayco) or die(mysql_error());
$row_user_solicitante = mysql_fetch_assoc($user_solicitante);
$totalRows_user_solicitante = mysql_num_rows($user_solicitante);
?>
<doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title>
<!-- 
Para obtener más información sobre los comentarios condicionales situados alrededor de las etiquetas html en la parte superior del archivo:
paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/
  
Haga lo siguiente si usa su compilación personalizada de modernizr (http://www.modernizr.com/):
* inserte el vínculo del código js aquí
* elimine el vínculo situado debajo para html5shiv
* añada la clase "no-js" a las etiquetas html en la parte superior
* también puede eliminar el vínculo con respond.min.js si ha incluido MQ Polyfill en su compilación de modernizr 
-->
<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</script>
<script type="text/javascript">
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
</head>
<body>

    <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#CCC" style="border-radius:5px; color:#000; font-weight:bold">
      <tr>
        <td align="center" style="font-size:24px; color:#006">Solicitud de Pago</td>
      </tr>
      <tr>
        <td height="26" align="center"><?php if ($row_solicitud['tipo_usuario_solicitud_pago'] == 'cliente') {?><table width="100%" border="0" cellspacing="0" cellpadding="0" style=" font-weight:bold; color:#009; font-size:14px">
          <tr>
            <td rowspan="3" width="30"><img src="logos/<?php if($row_cliente['logo_cliente'] == ''){echo 'sin_foto.png';}else{echo $row_cliente['logo_cliente'];} ?>" width="50" height="50"></td>
            <td rowspan="3" width="8">&nbsp;</td>
            <td><?php echo $row_cliente['nombre_cliente']; ?></td>
          </tr>
          <tr>
            <td><?php echo $row_cliente['lema_cliente']; ?></td>
          </tr>
          <tr>
            <td><?php echo $row_cliente['vigencia_cliente']; ?></td>
          </tr>
        </table>
        <?php }else{?>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" style=" font-weight:bold; color:#009; font-size:14px">
          <tr>
            <td width="50"><img src="logos/<?php if($row_cliente['logo_cliente'] == ''){echo 'sin_foto.png';}else{echo $row_cliente['logo_cliente'];} ?>" width="50" height="50"></td>
            <td width="496"><?php echo $row_user_solicitante['nombres_user']; ?></td>
          </tr>
        </table>
        <?php }?>
        </td>
      </tr>
      <tr>
        <td height="26" align="center">
          <div data-role="collapsible-set">
            <div data-role="collapsible">
              <h3>Pago de <?php echo number_format($row_solicitud['valor_solicitud_pago'],2); ?> <?php echo $row_solicitud['moneda_solicitud_pago']; ?></h3>
              <?php echo $row_solicitud['concepto_solicitud_pago']; ?>
            </div>
</div></td>
      </tr>
      <tr>
        <td height="26" align="center">
        <div data-role="fieldcontain">
            <select name="flipswitch" id="flipswitch" data-role="slider" onChange="MM_jumpMenu('parent',this,0)">
              <option value="operaciones/pago_cancelado.php?id=<?php echo $row_solicitud['id_solicitud_pago']; ?>">Pagar</option>
              <option value="operaciones/pago_directo.php?id=<?php echo $row_solicitud['id_solicitud_pago']; ?>">Cancelar</option>
            </select>
        </div>
        </td>
      </tr>
      <tr>
        <td height="26" align="center">
        <form action="operaciones/pago_cancelado.php?id=<?php echo $row_solicitud['id_solicitud_pago']; ?>">
        <input type="submit" value="Cancelar Pago" />
        </form>
        </td>
      </tr>
      <tr>
        <td align="center">
          
        </td>
      </tr>
    </table>
<?php if ($totalRows_solicitud == 0){
	header("Location: gopayco.php");
	} ?>
</body>
</html>
<?php
mysql_free_result($solicitud);

mysql_free_result($cliente);

mysql_free_result($user_solicitante);
?>
