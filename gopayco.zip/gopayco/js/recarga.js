// JavaScript Document
function subir(){
	var cantidad = '10000';
	var valor = document.getElementById('cantidad').value;
	var mult = document.getElementById('mult').value;
	var respuesta = cantidad * mult;
	document.getElementById('cantidad').value = respuesta;
	
	}