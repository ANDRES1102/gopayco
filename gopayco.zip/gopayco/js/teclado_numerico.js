// JavaScript Document
function uno(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('uno').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function dos(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('dos').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function tres(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('tres').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function cuatro(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('cuatro').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function cinco(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('cinco').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function seis(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('seis').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function siete(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('siete').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
	function ocho(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('ocho').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function nueve(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('nueve').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function cero(){
	var teclado = document.getElementById('passwordinput').value;
	var numero = document.getElementById('cero').value;
	document.getElementById('passwordinput').value = teclado+numero;
		}
		
function reloadx(){
	document.getElementById('passwordinput').value = ''
	}
	
function pagar_directo(){
	var id = document.getElementById('id_url').value;
	var clave = document.getElementById('passwordinput').value;
	if(clave == ''){}else{
	window.location = 'pagar_directo.php?id='+id+'&clave='+clave;	
	}
	}


function retirar_fondo(){
	var id = document.getElementById('id_saldos').value;
	var clave = document.getElementById('passwordinput').value;
	var banco = document.getElementById('selectmenu').value;
	var valor = document.getElementById('textinput').value;
	var cuenta = document.getElementById('textinput2').value;
	if(clave == ''){}else{
	window.location = 'retiro_solicitud.php?id='+id+'&clave='+clave+'&selectmenu='+banco+'&textinput='+valor+'&textinput2='+cuenta;	
	}
	}



function confirmar_envio(){
	var clave = document.getElementById('passwordinput').value;
	var usuario = document.getElementById('usuario').value;
	var valor = document.getElementById('valor').value;

	if(clave == ''){}else{
	window.location = 'pagar_envio.php?clave='+clave+'&usuario='+usuario+'&valor='+valor;
	}
	}


	
function pago_cancelado(){
	var id = document.getElementById('id_url').value;
	window.location = 'pago_cancelado.php?id='+id;
	}
	
