// JavaScript Document
function objetoAjax(){
	var xmlhttp=false;
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
 
	try {
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	} catch (E) {
		xmlhttp = false;
	}
}
 
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
	  xmlhttp = new XMLHttpRequest();
	}
	return xmlhttp;
} 

function carga_inicial(){
	user = document.getElementById('user').value;
	divResultado = document.getElementById('solicitud_pago');
  ajax=objetoAjax();
  ajax.open("POST", "operaciones/carga.php",true);
  ajax.onreadystatechange=function() {
  	if (ajax.readyState==4) {
		divResultado.innerHTML = ajax.responseText
	}
 }
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax.send("user="+user);
}

function solicitud_pago(){
	var monto = document.getElementById('textinput').value;
	var banco = document.getElementById('selectmenu').value;
	var cuenta = document.getElementById('textinput2').value;
	var saldo = document.getElementById('saldo').value;
	var minimo = document.getElementById('minimo').value;
	
	if(monto == '' || banco == '' || cuenta == ''){
		document.getElementById('enviar').type = 'button';
		}else{
			document.getElementById('enviar').type = 'submit';
			}
			
	if(monto > saldo){
		document.getElementById('monto_alto').style.display = 'inline';
		document.getElementById('enviar').type = 'button';
		}
		
		if(monto < minimo){
		document.getElementById('monto_bajo').style.display = 'inline';
		document.getElementById('enviar').type = 'button';
		}
	}
function recargar(){
	window.location = 'gopayco.php';
	}


function validacion_envio(){
	var cedula = document.getElementById('textinput').value;
	var valor = document.getElementById('textinput3').value;
	if(cedula == '' || valor == ''){
		document.getElementById('siguiente').type = 'button';
		}else{
			document.getElementById('siguiente').type = 'submit';			
			}
	}